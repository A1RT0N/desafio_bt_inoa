namespace StockAlert.Core.Alert;

public readonly record struct Thresholds(decimal SellAbove, decimal BuyBelow);
